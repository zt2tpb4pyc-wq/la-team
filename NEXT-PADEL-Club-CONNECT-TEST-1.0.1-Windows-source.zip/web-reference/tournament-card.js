/* Read-only presentation: ordinary player QR and canonical pilot mode. */
(()=>{'use strict';
 let key='',stop=()=>{},card=null,epoch=0,revision=-1,mode='',confirmed=false,queued=false;
 const label=m=>m==='autopilot'?'Mode Autopilot':m==='manual'?'Mode Manuel':'Vérification du mode…';
 function text(node,value){if(node&&node.textContent!==value)node.textContent=value}
 function paint(){if(!card?.isConnected)return;text(card.querySelector('[data-cc-mode]'),confirmed?label(mode):'Vérification du mode…');text(card.querySelector('[data-cc-mode-note]'),confirmed?'':'Synchronisation du mode à confirmer');card.dataset.mode=confirmed?mode:'unconfirmed'}
 function unbind(){epoch++;stop();stop=()=>{};key='';revision=-1;mode='';confirmed=false}
 function render(){queued=false;const c=window.LaTeamV2Experience?.clubCardContext?.();
  const game=document.getElementById('game');
  const host=c?.view==='tournament-module'&&game&&!game.classList.contains('hidden')?game:c?.view==='event-detail'?document.querySelector('#v2Experience .v2x-event-cockpit'):null;
  if(!c||c.role!=='CLUB'||!host){if(key)unbind();card?.remove();card=null;return}
  const uid=ClubLocal.auth.currentUser?.uid||'',next=[uid,c.eventId,c.publicCode||''].join('/');
  if(!card?.isConnected||card.dataset.event!==c.eventId){card?.remove();card=document.createElement('section');card.className='cc-tournament-card';card.dataset.event=c.eventId;card.setAttribute('aria-label','QR Joueurs et mode du tournoi');card.innerHTML='<div class="cc-tournament-qr" aria-label="QR Joueurs du tournoi"></div><div class="cc-tournament-info"><strong data-cc-mode role="status"></strong><small data-cc-mode-note></small><h2>QR Joueurs</h2><p>Scannez pour rejoindre ou retrouver votre match.</p><p>Code : <b data-cc-code></b></p><button type="button" class="secondary">AGRANDIR LE QR JOUEURS</button></div>';host.insertBefore(card,host.firstChild);card.querySelector('button').onclick=()=>{LaTeamV2Experience.openShare('registration',c.eventId);LaTeamV2Experience.openShareFullscreen()};}
  if(card.dataset.qr!==c.qrUrl){const qr=qrcode(0,'M');qr.addData(c.qrUrl);qr.make();card.querySelector('.cc-tournament-qr').innerHTML=qr.createSvgTag(8,4);card.dataset.qr=c.qrUrl;text(card.querySelector('[data-cc-code]'),c.joinCode||'—')}
  if(next!==key){unbind();key=next;const gen=epoch;
   if(c.publicCode){stop=ClubLocal.db.doc('tournaments/'+c.publicCode+'/runtime/current').onSnapshot({includeMetadataChanges:true},s=>{
    if(gen!==epoch)return;const r=s.exists?s.data():null;
    if(s.metadata.fromCache||s.metadata.hasPendingWrites||!navigator.onLine){confirmed=false;paint();return}
    const n=Number(r?.revision);if(!r||!Number.isSafeInteger(n)||n<revision||!['manual','autopilot'].includes(r.pilotMode)||(n===revision&&mode&&mode!==r.pilotMode)){confirmed=false;paint();return}
    revision=n;mode=r.pilotMode;confirmed=true;paint();
   },()=>{if(gen===epoch){confirmed=false;paint()}})}
  }
  if(!c.publicCode){mode=c.initialMode;confirmed=['manual','autopilot'].includes(mode)}paint();
 }
 function schedule(){if(queued)return;queued=true;queueMicrotask(render)}
 const observer=new MutationObserver(schedule);function observe(){for(const id of ['v2Experience','game']){const node=document.getElementById(id);if(node)observer.observe(node,{childList:true,subtree:true,attributes:true,attributeFilter:['class']})}}observe();
 window.addEventListener('offline',()=>{confirmed=false;paint()});window.addEventListener('online',()=>{unbind();schedule()});window.addEventListener('pageshow',()=>{observe();schedule()});window.addEventListener('pagehide',()=>{unbind();observer.disconnect()});schedule();
})();
