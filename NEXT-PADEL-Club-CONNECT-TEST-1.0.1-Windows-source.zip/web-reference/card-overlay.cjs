'use strict';
const assert=require('node:assert/strict');
// Only expose the existing share URL and current event to the candidate presentation.
// No registration handler, identity, session or sporting command is replaced.
module.exports=function(source){const anchor='root.LaTeamV2Experience={';assert.equal(source.split(anchor).length-1,1);
 const context="clubCardContext:()=>{const e=runtime.events.find(x=>x.eventId===runtime.currentEventId);if(!e)return null;return {role:runtime.role,view:runtime.view,eventId:e.eventId,publicCode:e.publicCode||'',joinCode:e.eventJoinCode||'',qrUrl:shareUrl('registration',e),initialMode:typeof state==='object'?state.autopilot?.mode||'manual':'manual'};},";
 return source.replace(anchor,anchor+context);
};
