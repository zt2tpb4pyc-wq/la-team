'use strict';
// Visual fixtures only. Never imported by the sporting application or by its service.
const Timer=require('./ui/round-timer.js');
const Screens=require('./shared/screens/core.js');
const Courts=require('./ui/court-model.js');
const Profile=require('./ui/profile.js');
const preference=Profile.normalize;
const MAX_LIVE_COURTS=4,CONFIGURABLE_COURTS=8;
function defaults(){const c=Courts.defaults();c.activeCount=8;return {courts:c,profiles:Array.from({length:8},()=>preference()),selected:[1,2,3],overviewPageSize:4};}
function normalize(raw){if(raw&&!('overviewPageSize' in raw))raw={...raw,overviewPageSize:4};if(!raw||Object.keys(raw).sort().join(',')!=='courts,overviewPageSize,profiles,selected'||![2,4,8].includes(raw.overviewPageSize))throw Error('Configuration inconnue.');const courts=Courts.normalize(raw.courts);if(raw.profiles?.length!==8)throw Error('Huit profils requis.');if(!Array.isArray(raw.selected)||raw.selected.length>MAX_LIVE_COURTS||new Set(raw.selected).size!==raw.selected.length||raw.selected.some(n=>!Number.isInteger(n)||n<1||n>courts.activeCount))throw Error('Sélection invalide : quatre terrains maximum en diffusion simultanée.');return {courts,profiles:raw.profiles.map(preference),overviewPageSize:raw.overviewPageSize,selected:raw.selected.slice().sort((a,b)=>a-b)};}
const names=['Alex','Sam','Charlie','Noa','Robin','Camille','Lou','Sacha','Eden','Max','Jules','Léa','Morgan','Alix','Emy','Liam','Cléo','Nino','Mila','Andy','Rose','Tom','Kim','Luc','Iris','Yann','Maé','Jo','Eli','Nora','Axel','Zoé'];
function fixture(scene='running',now=Date.now(),round=3){
 const allowed=['target','running','paused','stopped','completed','overview3','overview4','overview8','overview8long','long','waiting','stale','finished'];if(!allowed.includes(scene))throw Error('Scénario inconnu.');
 const overview=scene.startsWith('overview'),count=scene==='overview3'?3:scene==='overview4'?4:8;
 const players=Array.from({length:count*4},(_,i)=>({name:(scene==='long'||scene==='overview8long')?['Alexandre Dupont-Martin','Marie-Charlotte Leroy','Jean-Baptiste Moreau','Anne-Sophie Delacroix'][i%4]:names[i]}));
 const publication={endMode:'time',timerMode:'common',tournamentName:'Rencontre du club · Démonstration',players,roundDurationMinutes:10};
 const runtime={roundNumber:round,activeScheduleVersion:round,status:scene==='finished'?'finished':'live'};
 const assignments={roundNumber:round,assignmentVersion:round,courts:Array.from({length:count},(_,i)=>({number:i+1,teamA:[i*4,i*4+1],teamB:[i*4+2,i*4+3]}))};
 let timer=Timer.idle(round,10);if(!overview&&scene!=='waiting'){timer={...timer,state:['paused','stopped','completed'].includes(scene)?scene:'running',roundStartedAt:now,remainingMs:scene==='completed'?0:582000,generation:1}};
 return {scene,roundNumber:round,feed:scene==='waiting'?null:Screens.project(publication,runtime,assignments,timer),confirmedAt:now,anchor:now};
}
module.exports={MAX_LIVE_COURTS,CONFIGURABLE_COURTS,preference,defaults,normalize,fixture};
