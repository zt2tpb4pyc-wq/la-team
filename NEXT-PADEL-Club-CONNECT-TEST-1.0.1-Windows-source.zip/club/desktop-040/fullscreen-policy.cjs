'use strict';
// Permission only; never reads or writes sporting data or projection preferences.
function isProjectionURL(value,origin,requireKey=true){
 try{const url=new URL(value),base=new URL(origin);if(base.protocol!=='http:'||base.hostname!=='127.0.0.1'||url.origin!==base.origin||url.username||url.password||url.pathname!=='/display'||url.search)return false;
  return !requireKey||/^[a-f0-9]{48}$/.test(new URLSearchParams(url.hash.slice(1)).get('key')||'');
 }catch{return false}
}
function createFullscreenPolicy({origin,isProjectionContents}){
 return (contents,permission,details,requestingOrigin)=>{
  try{
   // No automatic fullscreen, embedded preview, manager, phone or other permission.
   if(permission!=='fullscreen'||!contents||contents.isDestroyed()||!isProjectionContents(contents)||details?.isMainFrame!==true)return false;
   if(!isProjectionURL(contents.getURL(),origin)||!isProjectionURL(details.requestingUrl,origin,false))return false;
   if(requestingOrigin!==undefined&&new URL(requestingOrigin).origin!==origin)return false;
   return true;
  }catch{return false}
 };
}
module.exports={createFullscreenPolicy,isProjectionURL};
