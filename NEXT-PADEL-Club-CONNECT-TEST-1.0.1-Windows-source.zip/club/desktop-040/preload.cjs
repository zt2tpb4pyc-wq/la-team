'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('clubUI',{call:(action,payload={})=>ipcRenderer.invoke('club-ui:action',action,payload),onState:fn=>{const cb=(_,state)=>fn(state);ipcRenderer.on('club-ui:state',cb);return()=>ipcRenderer.removeListener('club-ui:state',cb)}});
