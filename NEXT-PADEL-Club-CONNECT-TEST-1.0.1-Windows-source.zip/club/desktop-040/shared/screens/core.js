(function(root,factory){const api=factory(typeof module==='object'?require('../round-timer.js'):root.LaTeamRoundTimer);if(typeof module==='object')module.exports=api;root.NextPadelScreens=api;})(typeof globalThis!=='undefined'?globalThis:this,function(Timer){
'use strict';
const STALE_MS=90000,HEARTBEAT_MS=60000,LEASE_MS=6*3600000;
const clean=x=>String(x??'').trim().slice(0,80),ms=x=>x?.toMillis?.()??(typeof x==='number'?x:null);
function project(publication,runtime,round,timer){
 if(!publication||!runtime||!round||round.roundNumber!==runtime.roundNumber||round.assignmentVersion!==runtime.activeScheduleVersion)return null;
 if(publication.endMode!=='time')throw Error('Prototype limité au mode Timer : le mode Points ne fournit pas de départ du chrono canonique.');
 if(publication.timerMode==='individual')throw Error('Les chronos individuels ne sont pas pris en charge dans ce prototype.');
 if(publication.endMode==='time'&&(!timer||timer.roundNumber!==runtime.roundNumber))return null;
 const name=id=>{const participant=publication.participantIds?.[id];const value=publication.playerNames?.[participant]||publication.players?.[id]?.name;if(typeof value!=='string'||!value.trim())throw Error('Nom affichable non confirmé');return clean(value)};
 if(!Array.isArray(round.courts)||round.courts.length<1||round.courts.length>8)throw Error('1 à 8 terrains requis');
 const courts=round.courts.map(c=>{if(!Number.isInteger(c.number)||c.number<1||c.number>8||c.teamA?.length!==2||c.teamB?.length!==2)throw Error('Affectation invalide');return {number:c.number,teamA:c.teamA.map(name),teamB:c.teamB.map(name)}});
 if(new Set(courts.map(c=>c.number)).size!==courts.length)throw Error('Terrains dupliqués');
 const t=Timer.normalize(timer,runtime.roundNumber,publication.roundDurationMinutes||1);
 return {schemaVersion:1,title:clean(publication.tournamentName||'Tournoi'),roundNumber:runtime.roundNumber,assignmentVersion:round.assignmentVersion,status:runtime.status,endMode:publication.endMode==='time'?'time':'points',courts,timer:{state:t.state,roundNumber:t.roundNumber,durationMinutes:t.durationMinutes,roundStartedAt:ms(t.roundStartedAt),remainingMs:t.remainingMs,generation:Number(t.generation)||0}};
}
function phase(feed,now=Date.now()){
 if(feed.status==='finished')return 'finished';if(feed.status==='aborted')return 'aborted';
 if(feed.endMode==='points')return 'points';
 const state=Timer.effectiveState(feed.timer,now);return state==='not_started'?'overview':['stopped','completed'].includes(state)?'ended':state;
}
function view(feed,court,{now=Date.now(),lastConfirmedAt=0,online=true,denied=false}={}){
 if(denied)return {phase:'revoked',message:'DIFFUSION INTERROMPUE — accès expiré ou révoqué'};
 if(!feed)return {phase:'waiting',message:'CONNEXION À L’ÉCRAN…'};
 if(now>=ms(feed.expiresAt))return {phase:'revoked',message:'ACCÈS EXPIRÉ'};
 if(!online||now-lastConfirmedAt>STALE_MS)return {phase:'stale',message:'DONNÉES OBSOLÈTES — reconnexion en cours'};
 const current=feed.courts.find(c=>c.number===court);if(!current)return {phase:'waiting',message:'TERRAIN NON AFFECTÉ'};
 const state=phase(feed,now);return {phase:state,title:feed.title,round:feed.roundNumber,court,clock:feed.endMode==='time'?Timer.label(feed.timer,now):'MODE POINTS',courts:state==='overview'?feed.courts:[current]};
}
function token(crypto=globalThis.crypto){return Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('')}
function address(origin,key,court){if(!/^[a-f0-9]{64}$/.test(key)||!Number.isInteger(court)||court<1||court>4)throw Error('Lien invalide');const u=new URL('/screens/display.html',origin);u.hash=new URLSearchParams({key,court});return u.href}
function parse(url){const p=new URLSearchParams(new URL(url).hash.slice(1)),key=p.get('key'),court=Number(p.get('court'));address('https://example.invalid',key,court);return {key,court}}
function estimate({screens,rounds,hours=2,changesPerRound=5,reconnections=0}){
 const writes=Math.ceil(hours*60)+rounds*changesPerRound+1;
 const displayDocumentReads=screens*(writes+1+reconnections),dependentRuleReadsUpperBound=displayDocumentReads+screens;
 const sourceReadsUpperBound=4+rounds*(changesPerRound+1),writeRuleReadsUpperBound=writes*2+8;
 return {feedWritesUpperBound:writes,totalWritesUpperBound:writes+3,displayDocumentReads,dependentRuleReadsUpperBound,sourceReadsUpperBound,writeRuleReadsUpperBound,totalReadsUpperBound:displayDocumentReads+dependentRuleReadsUpperBound+sourceReadsUpperBound+writeRuleReadsUpperBound,perSecondReads:0};
}
return {STALE_MS,HEARTBEAT_MS,LEASE_MS,project,phase,view,token,address,parse,estimate};
});
