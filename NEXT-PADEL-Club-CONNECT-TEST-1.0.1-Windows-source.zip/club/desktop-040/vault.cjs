'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
// Firebase's persistence adapter stays in Electron main, never in a renderer.
// No plaintext fallback: failure keeps the old encrypted file and stops startup.
function persistenceClass(directory,safeStorage){
 function available(){if(!safeStorage.isEncryptionAvailable())throw Error('SECURE_STORAGE_UNAVAILABLE');}
 const file=key=>path.join(directory,crypto.createHash('sha256').update(key).digest('hex')+'.vault');
 return class EncryptedPersistence {
  constructor(){this.type='LOCAL';this._shouldAllowMigration=false;}
  async _isAvailable(){available();return true;}
  async _get(key){available();const f=file(key);if(!fs.existsSync(f))return null;try{return JSON.parse(safeStorage.decryptString(fs.readFileSync(f)))}catch{throw Error('SECURE_STORAGE_UNREADABLE')}}
  async _set(key,value){available();const encrypted=safeStorage.encryptString(JSON.stringify(value));fs.mkdirSync(directory,{recursive:true,mode:0o700});fs.chmodSync(directory,0o700);const f=file(key),tmp=f+'.'+crypto.randomBytes(6).toString('hex')+'.tmp';try{fs.writeFileSync(tmp,encrypted,{mode:0o600,flag:'wx'});fs.renameSync(tmp,f)}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp)}}
  async _remove(key){available();fs.rmSync(file(key),{force:true});}
  _addListener(){} _removeListener(){} // Single-instance main process owns this storage.
 };
}
module.exports={persistenceClass};
