'use strict';
// Management UI only. Deliberately separate from court profiles and projection packets.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
function validate(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).join(',')!=='theme'||!['day','night'].includes(raw.theme))throw Error('Thème d’interface invalide.');return {theme:raw.theme}}
function createAppearance(directory){
 const file=path.join(directory,'interface-appearance.json');let theme='night',readOnly=false;
 try{const stat=fs.lstatSync(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.size>1024)throw Error('Fichier refusé');theme=validate(JSON.parse(fs.readFileSync(file,'utf8'))).theme}catch(e){if(e.code!=='ENOENT')readOnly=true}
 return {get:()=>({theme}),save(raw){const next=validate(raw);if(readOnly)throw Error('Préférence illisible : original conservé, thème non enregistré.');fs.mkdirSync(directory,{recursive:true,mode:0o700});const tmp=file+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';try{if(fs.existsSync(file)){const s=fs.lstatSync(file);if(!s.isFile()||s.isSymbolicLink())throw Error('Fichier de préférence refusé.');fs.copyFileSync(file,file+'.last-good')}fs.writeFileSync(tmp,JSON.stringify(next)+'\n',{flag:'wx',mode:0o600});fs.renameSync(tmp,file);theme=next.theme;}finally{if(fs.existsSync(tmp))fs.unlinkSync(tmp)}return {theme}}};
}
module.exports={validate,createAppearance};
