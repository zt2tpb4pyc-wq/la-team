(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.CourtsModel=api})(typeof globalThis==='object'?globalThis:this,function(){
 'use strict';
 const SCHEMA=1,MAX_COURTS=8;
 // Static data registry. Future connectors must be reviewed and registered in the main process.
 // A saved method ID is configuration, never authorization to execute code or contact a device.
 const METHODS=Object.freeze([
  {id:'undetermined',label:'Connexion non déterminée',fields:[],help:'Identifiez le matériel avant de choisir une connexion.'},
  {id:'browser',label:'Page web / navigateur',fields:['address'],help:'Un futur connecteur pourra ouvrir une page autorisée. Aucun lien saisi ici ne sera ouvert.'},
  {id:'video',label:'Sortie vidéo HDMI / DisplayPort',fields:['videoConnector','outputLabel'],help:'La mire locale pourra ensuite être déplacée manuellement vers une sortie déjà raccordée, après autorisation. Aucun réglage vidéo n’est changé.'},
  {id:'network',label:'Connexion réseau IP / Wi-Fi',fields:['address','port'],help:'Renseignez une adresse connue du gérant. Aucun scan, ping ou accès réseau ne sera effectué.'},
  {id:'manufacturer',label:'Logiciel ou API du fabricant',fields:['vendor','software','address','port'],help:'La documentation et les droits du fabricant devront être audités. Aucun logiciel tiers n’est lancé.'}
 ].map(x=>Object.freeze({...x,testImplemented:false,testAuthorized:false})));
 const fields=Object.freeze(['deviceName','address','port','videoConnector','outputLabel','vendor','software','hardware','notes']);
 const lengths={deviceName:80,address:256,outputLabel:80,vendor:80,software:80,hardware:240,notes:600,videoConnector:24};
 function fail(code,message){const e=Error(message);e.code=code;throw e}
 function object(o){return o&&typeof o==='object'&&!Array.isArray(o)}
 function exact(o,keys){if(!object(o)||Object.keys(o).some(k=>!keys.includes(k))||keys.some(k=>!(k in o)))fail('SCHEMA','Format de configuration invalide.');}
 function sensitive(value){return /(?:password|passwd|mot\s+de\s+passe|api[_ -]?key|token|secret|authorization)\s*[:=]|\bbearer\s+\S+|-----BEGIN .*PRIVATE KEY-----|:\/\/[^\s/]+@/i.test(value)}
 function text(value,key){if(typeof value!=='string'||value.length>lengths[key]||/[\x00-\x08\x0b-\x1f\x7f]/.test(value))fail('FIELD','Champ invalide ou trop long : '+key);if(sensitive(value))fail('SECRET','Ne saisissez aucun mot de passe, jeton ou secret dans la configuration.');return value.trim()}
 function address(value){if(!value)return '';let u;try{u=new URL(value.includes('://')?value:'https://'+value)}catch{fail('ADDRESS','Adresse invalide. Utilisez une URL HTTP(S), un nom d’hôte ou une adresse IP connue.');}
  if(!['http:','https:'].includes(u.protocol)||!u.hostname||u.username||u.password||u.search||u.hash||value.includes('\\')||/\s/.test(value))fail('ADDRESS','Adresse refusée : ni identifiant, ni paramètre, ni fragment, ni chemin de fichier.');return value;
 }
 function emptyCourt(number){return {id:'court-'+number,number,method:'undetermined',deviceName:'',address:'',port:null,videoConnector:'unspecified',outputLabel:'',vendor:'',software:'',hardware:'',notes:''}}
 function defaults(){return {schema:SCHEMA,revision:0,activeCount:3,courts:Array.from({length:MAX_COURTS},(_,i)=>emptyCourt(i+1))}}
 function court(raw,number){if(!Number.isInteger(number)||number<1||number>MAX_COURTS)fail('IDENTITY','Terrain hors limites.');exact(raw,['id','number','method',...fields]);if(raw.id!=='court-'+number||raw.number!==number)fail('IDENTITY','Identifiant de terrain invalide.');if(typeof raw.method!=='string'||!/^[a-z][a-z0-9-]{0,39}$/.test(raw.method))fail('METHOD','Méthode invalide.');const c={id:raw.id,number,method:raw.method};for(const key of fields){if(key==='port'){if(raw.port!==null&&(!Number.isInteger(raw.port)||raw.port<1||raw.port>65535))fail('PORT','Le port doit être vide ou compris entre 1 et 65535.');c.port=raw.port}else c[key]=text(raw[key],key)}address(c.address);if(!['unspecified','hdmi','displayport','usb-c-video'].includes(c.videoConnector))fail('CONNECTOR','Sortie vidéo invalide.');return c}
 function normalize(raw){exact(raw,['schema','revision','activeCount','courts']);if(raw.schema!==SCHEMA)fail('VERSION','Version de fichier non prise en charge. Fichier conservé.');if(!Number.isSafeInteger(raw.revision)||raw.revision<0)fail('REVISION','Révision invalide.');if(!Number.isInteger(raw.activeCount)||raw.activeCount<1||raw.activeCount>MAX_COURTS)fail('COUNT','Choisissez entre 1 et 8 terrains.');if(!Array.isArray(raw.courts)||raw.courts.length!==MAX_COURTS)fail('COUNT','Huit emplacements stables sont nécessaires.');return {schema:SCHEMA,revision:raw.revision,activeCount:raw.activeCount,courts:raw.courts.map((c,i)=>court(c,i+1))}}
 function ready(c){const m=METHODS.find(m=>m.id===c.method);if(!m||m.id==='undetermined'||!c.deviceName)return false;if(['browser','network'].includes(c.method)&&!c.address)return false;if(c.method==='video'&&c.videoConnector==='unspecified')return false;if(c.method==='manufacturer'&&(!c.vendor||!c.software))return false;return true}
 function fingerprint(c){return JSON.stringify(court(c,c.number))}
 function status(c,evidence=null,capabilities=METHODS){if(!ready(c))return {id:'unconfigured',label:'Non configuré'};const adapter=capabilities.find(x=>x.id===c.method),valid=adapter?.testImplemented===true&&adapter?.testAuthorized===true&&evidence?.fingerprint===fingerprint(c)&&evidence?.connection?.success===true&&Number.isFinite(evidence.connection.at)&&evidence.connection.at>0;
  if(valid&&evidence?.projection?.humanConfirmed===true&&Number.isFinite(evidence.projection.at)&&evidence.projection.at>=evidence.connection.at)return {id:'projection-confirmed',label:'Projection confirmée'};
  return valid?{id:'connection-tested',label:'Connexion testée'}:{id:'configured',label:'Configuré'};
 }
 function mergeCourt(config,value){const c=court(value,value.number);if(c.number>config.activeCount)fail('INACTIVE','Ce terrain est inactif.');return normalize({...config,courts:config.courts.map(x=>x.number===c.number?c:x)})}
 // Pure integration contract: never issues, persists or extends any grant. The trusted
 // future association adapter must provide a freshly server-verified scope, not this UI.
 function authorizedCourts(config,scope,now=Date.now()){if(!scope||scope.source!=='server-confirmed'||scope.status!=='active'||!Number.isFinite(scope.expiresAt)||scope.expiresAt<=now||!Array.isArray(scope.courts))return [];return config.courts.filter(c=>c.number<=config.activeCount&&scope.courts.includes(c.number)).map(c=>({id:c.id,number:c.number}));}
 return {SCHEMA,MAX_COURTS,METHODS,fields,defaults,normalize,court,ready,status,fingerprint,mergeCourt,authorizedCourts};
});
