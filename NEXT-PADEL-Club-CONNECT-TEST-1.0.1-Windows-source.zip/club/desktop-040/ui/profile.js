(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ClubProjectionProfile=api})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const fields=['background','timer','text','title','separation'];
 const accents={lime:'#c1ff38',yellow:'#ffe83d',cyan:'#74efff',white:'#ffffff'};
 const dark={lime:'#285500',yellow:'#665000',cyan:'#00545e',white:'#050505'};
 function defaults(){return {background:'#000000',timer:'#c1ff38',text:'#ffffff',title:'#c1ff38',separation:'#818c7b'}}
 function legacy(p){const a=(p.inverted?dark:accents)[p.color];return {background:p.inverted?'#ffffff':'#000000',timer:a,text:p.inverted?'#050505':'#ffffff',title:a,separation:p.inverted?'#4b5147':'#818c7b'}}
 function palette(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).sort().join(',')!==fields.slice().sort().join(',')||fields.some(k=>typeof raw[k]!=='string'||!/^#[0-9a-f]{6}$/i.test(raw[k])))throw Error('Les couleurs doivent utiliser le format #RRGGBB.');return Object.fromEntries(fields.map(k=>[k,raw[k].toLowerCase()]))}
 function normalize(raw={}){const p={profile:'visibility',color:'lime',timerSize:100,nameSize:100,secondary:true,inverted:false,orientation:'normal',...raw};
 if(Object.keys(p).filter(k=>k!=='palette').sort().join(',')!=='color,inverted,nameSize,orientation,profile,secondary,timerSize'||!['visibility','contrast','custom'].includes(p.profile)||!Object.hasOwn(accents,p.color)||![80,100,120].includes(p.timerSize)||![100,120].includes(p.nameSize)||typeof p.secondary!=='boolean'||typeof p.inverted!=='boolean'||!['normal','inverted'].includes(p.orientation))throw Error('Préférences de projection invalides.');
 return {...p,palette:palette(p.palette===undefined?legacy(p):p.palette)};
 }
 function resolved(p){p=normalize(p);return p.profile==='custom'?p.palette:{...defaults(),timer:p.profile==='contrast'?accents.yellow:accents.lime,title:p.profile==='contrast'?accents.yellow:accents.lime}}
 function luminance(hex){return hex.slice(1).match(/../g).map(v=>parseInt(v,16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((n,v,i)=>n+v*[.2126,.7152,.0722][i],0)}
 function ratio(a,b){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05)}
 function contrasts(p){const c=resolved(p);return ['timer','text','title','separation'].map(key=>{const value=ratio(c[key],c.background),minimum=key==='separation'?3:4.5;return {key,value,minimum,pass:value>=minimum}})}
 return {fields,defaults,legacy,palette,normalize,resolved,ratio,contrasts};
});
