'use strict';
function createMetrics(){const rows=[],active=new Map();let next=0;return {
 add(operation,kind,n=1){rows.push({operation,kind,n,ms:Date.now()})},
 open(kind,path){const id=++next;active.set(id,{kind,path});this.add('listenOpened',kind);return()=>{if(active.delete(id))this.add('listenClosed',kind)}},
 snapshot(){const totals={};for(const e of rows){const k=e.operation+'/'+e.kind;totals[k]=(totals[k]||0)+e.n}return {totals,active:[...active.values()].map(x=>({kind:x.kind})),billing:false,ruleReads:'not measurable as billing by Emulator'}}
};}
module.exports={createMetrics};
