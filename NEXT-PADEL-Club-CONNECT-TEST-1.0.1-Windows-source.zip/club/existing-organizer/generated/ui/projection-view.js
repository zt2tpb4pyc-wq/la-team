(function(root,factory){const api=factory(typeof module==='object'?require('./round-timer.js'):root.LaTeamRoundTimer);if(typeof module==='object')module.exports=api;else root.ClubVisualView=api})(globalThis,function(Timer){
'use strict';
const FRESH_MS=90000,PAGE_MS=12000;
function view(packet,{now=Date.now(),width=1920,height=1080,connected=true}={}){
 if(!packet?.authorized||(packet.mode==='live'&&(!packet.accessExpiresAt||now>=packet.accessExpiresAt)))return {phase:'waiting',title:'DIFFUSION DÉSACTIVÉE',message:'En attente de l’organisateur',courts:[],stale:false};
 const d=packet.feed;
 if(!d)return {phase:'waiting',title:'EN ATTENTE DES PROCHAINES AFFECTATIONS',message:'Les affectations apparaîtront après leur confirmation.',courts:[],stale:!connected||packet.interrupted};
 const all=d.courts;if(!Array.isArray(all)||!all.some(c=>c.number===packet.court)&&Timer.effectiveState(d.timer,now)!=='not_started')return {phase:'waiting',title:'TERRAIN NON AFFECTÉ',message:'En attente des prochaines affectations',courts:[],stale:false};
 const stale=!connected||packet.interrupted||packet.scene==='stale'||now-packet.confirmedAt>FRESH_MS||packet.confirmedAt>now+5000;
 const state=Timer.effectiveState(d.timer,now),base={stale,round:d.roundNumber,court:packet.court,clock:Timer.label(d.timer,now),courts:all.filter(c=>c.number===packet.court),message:'',secondary:packet.profile.secondary,mode:packet.mode};
 if(packet.scene==='target')return {...base,phase:'target',title:'NEXT PADEL — TERRAIN '+packet.court};
 if(d.status==='finished')return {...base,phase:'finished',title:'TOURNOI TERMINÉ',message:'Les résultats sont disponibles dans NEXT PADEL.',courts:[]};
 if(stale&&state==='not_started')return {...base,phase:'waiting',title:'SYNCHRONISATION À CONFIRMER',message:'En attente des affectations confirmées.',courts:[]};
 if(state==='not_started'){
  // One shared page size and absolute anchor, including displays of different resolutions.
  const capacity=[2,4,8].includes(packet.overviewPageSize)?packet.overviewPageSize:4;
  const pages=Math.max(1,Math.ceil(all.length/capacity)),index=Math.floor(Math.max(0,now-packet.anchor)/PAGE_MS)%pages;
  return {...base,phase:'overview',title:'À VOUS DE JOUER',courts:all.slice(index*capacity,(index+1)*capacity),allCourts:all.map(c=>c.number),page:index+1,pages,capacity,untilNext:Math.ceil((PAGE_MS-Math.max(0,now-packet.anchor)%PAGE_MS)/1000)};
 }
 return {...base,phase:state,title:{running:'MATCH EN COURS',paused:'EN PAUSE',stopped:'ROUND ARRÊTÉ',completed:'TEMPS TERMINÉ'}[state]||'EN ATTENTE',message:['stopped','completed'].includes(state)?'En attente des prochaines affectations':''};
}
function accept(previous,next){if(!next||!Number.isSafeInteger(next.serial)||next.serial<0)return false;if(previous&&next.serial<previous.serial)return false;if(previous?.feed&&next.feed&&previous.feed.tournamentId===next.feed.tournamentId&&(next.feed.roundNumber<previous.feed.roundNumber||next.feed.roundNumber===previous.feed.roundNumber&&next.feed.assignmentVersion<previous.feed.assignmentVersion))return false;return true}
return {view,accept,FRESH_MS,PAGE_MS};
});
