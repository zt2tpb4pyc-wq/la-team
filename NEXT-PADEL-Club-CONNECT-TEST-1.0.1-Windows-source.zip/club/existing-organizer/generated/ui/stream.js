'use strict';
// Local-only presentation transport. Read only: no client command is sent through this socket.
window.ClubVisualStream=function(key,{message,error}){
 let socket,closed=false,retry=null,attempt=0;
 function connect(){if(closed)return;clearTimeout(retry);const url=new URL('/api/stream',location.origin);url.protocol='ws:';url.searchParams.set('key',key||'');socket=new WebSocket(url);socket.onmessage=e=>{try{const data=JSON.parse(e.data);attempt=0;message(data)}catch{error()}};socket.onerror=()=>error();socket.onclose=()=>{if(closed)return;error();retry=setTimeout(connect,Math.min(15000,1000*2**Math.min(attempt++,4)))}}
 connect();return {close(){closed=true;clearTimeout(retry);socket?.close()}};
};
