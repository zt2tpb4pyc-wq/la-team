'use strict';
// No projection, sport, form reconstruction or reload. Only the management root changes.
(()=>{const root=document.documentElement,buttons=[...document.querySelectorAll('[data-interface-theme]')],notice=document.getElementById('themeNotice');let desired=root.dataset.uiTheme==='day'?'day':'night',pending=false,saving=false;
 function paint(){root.dataset.uiTheme=desired;for(const button of buttons)button.setAttribute('aria-pressed',String(button.dataset.interfaceTheme===desired))}
 async function persist(){if(saving)return;saving=true;while(pending){pending=false;const theme=desired;try{const result=await window.clubUI.call('appearance',{theme});if(result.theme!==theme)throw Error('Enregistrement non confirmé.');notice.hidden=true;}catch{notice.textContent='Thème affiché mais non enregistré. Cliquez de nouveau sur Jour ou Nuit pour réessayer.';notice.hidden=false;}}saving=false;}
 for(const button of buttons)button.addEventListener('click',()=>{(button.closest('dialog')||document.body).append(notice);desired=button.dataset.interfaceTheme;paint();pending=true;persist()});paint();
})();
