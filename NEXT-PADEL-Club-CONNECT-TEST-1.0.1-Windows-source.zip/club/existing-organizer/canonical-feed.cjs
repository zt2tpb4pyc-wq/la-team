'use strict';
const F=require('firebase/firestore'),L=require('firebase/firestore/lite');
const {mapping}=require('./physical-model.cjs');
const Screens=require('../../screens/core.js'),Timer=require('../../round-timer.js');
const ms=x=>x?.toMillis?.()??Number(x||0);
function createFeed({db,lite,metrics,onChange=()=>{},onDenied=()=>{},now=Date.now,intervalMs=60000,full=F,liteSDK=L}){
 let epoch=0,code='',selected=[],off=[],dynamic=[],values={},highest={},paths={},versions={},feed=null,lastProof=0,stale=true,error='',timer=null,probing=null,scope='',confidence={},retryProof=null,proofRetries=0,refreshTask=null,lastRecovery={scope:'',at:0};
 const revision=(k,d)=>k==='timer'?[Number(d.generation)||0,ms(d.updatedAt)]:[Number(k==='round'?d.assignmentVersion:d.revision)||0];
 const less=(a,b)=>a.some((v,i)=>v!==b[i]&&a.slice(0,i).every((x,j)=>x===b[j])&&v<b[i]);
 function emit(){onChange(snapshot())}
 function snapshot(){return {feed,confirmed:lastProof,stale:stale||now()-lastProof>90000,error,code}}
 function compose(){try{const {publication:p,runtime:r,round,timer:t}=values;
  if(!p||!r||!round||!t||p.status!==r.status||Number(t.roundNumber)>Number(r.roundNumber)){feed=null;stale=true;emit();return}
  const next=Screens.project(p,r,round,Timer.normalize(t,r.roundNumber,p.roundDurationMinutes));if(!next){feed=null;stale=true;emit();return}
  next.tournamentId=p.tournamentId;next.revisions={runtime:r.revision,assignment:round.assignmentVersion,timerGeneration:Number(t.generation)||0,timerUpdatedAt:ms(t.updatedAt)};
  if(next.courts.length!==selected.length||next.courts.some((c,i)=>c.number!==i+1)){feed=null;stale=true;error='physical-court-count-mismatch';emit();return}
  // Translate only the display contract. Assignments, King rotations and match IDs stay sporting.
  next.courts=next.courts.map(c=>{const s=values['score'+c.number];return {...c,number:selected[c.number-1],physicalId:'court-'+selected[c.number-1],sportRank:c.number,...(s?.status==='validated'&&Number(s.roundNumber)===r.roundNumber&&s.matchId===`${p.tournamentId}_v${r.activeScheduleVersion}r${r.roundNumber}c${c.number}`?{score:{a:s.scoreA,b:s.scoreB,confirmed:true,revision:s.revision,roundNumber:r.roundNumber,assignmentVersion:r.activeScheduleVersion}}:{})}});
  next.updatedAt=ms(r.updatedAt);feed=next;error='';stale=!lastProof||now()-lastProof>90000||!Object.keys(paths).every(k=>confidence[k]);emit();
 }catch(e){error='incoherent-canonical-data';stale=true;emit()}}
 function clearDynamic(){
  dynamic.forEach(f=>f());dynamic=[];
  for(const k of Object.keys(paths))if(k==='round'||k.startsWith('score')){delete paths[k];delete values[k];delete highest[k];delete versions[k];delete confidence[k]}
  feed=null;lastProof=0;stale=true;
 }
 function dynamicSources(){const p=values.publication,r=values.runtime;if(!p?.tournamentId||!r)return;const current=`${p.clubId}/${p.tournamentId}/${r.activeScheduleVersion}/${r.roundNumber}/${selected.join(',')}`;if(current===scope)return;clearDynamic();scope=current;
  const rid=r.activeScheduleVersion===r.roundNumber?'r'+r.roundNumber:`v${r.activeScheduleVersion}_r${r.roundNumber}`;
  dynamic.push(watch('round',`tournaments/${code}/rounds/${rid}`));for(const {sportRank:c} of mapping(selected))dynamic.push(watch('score'+c,`clubs/${p.clubId}/tournaments/${p.tournamentId}/matches/${p.tournamentId}_v${r.activeScheduleVersion}r${r.roundNumber}c${c}`));
 }
 function denied(){stop();error='permission-denied';onDenied();emit()}
 function retryProbe(){if(retryProof||!code)return;retryProof=setTimeout(()=>{retryProof=null;probe().catch(()=>{})},1000);retryProof.unref?.()}
 // A current-round-only listener can lose permission BEFORE runtime/current reaches us.
 // Retire its whole scope, then ask the still-scoped runtime endpoint for the new round.
 // A revoked grant also denies that endpoint: it remains a hard stop, never a bypass.
 function retiredScope(){const previous=scope;clearDynamic();scope='';error='round-transition';emit();
  if(lastRecovery.scope===previous&&now()-lastRecovery.at<intervalMs)return;
  lastRecovery={scope:previous,at:now()};refreshRuntime().catch(()=>{});
 }
 async function refreshRuntime(){if(refreshTask||!code)return false;const gen=epoch,path=paths.runtime;
  const task=(async()=>{try{metrics.add('independentRequested','runtime');const s=await liteSDK.getDoc(liteSDK.doc(lite,path));if(gen!==epoch||paths.runtime!==path)return false;if(!accept('runtime',s,true))return false;return await probe();}
   catch(e){if(gen===epoch){if(e.code==='permission-denied')denied();else{error=e.code||'network';stale=true;emit()}}return false}
  })();refreshTask=task;try{return await task}finally{if(refreshTask===task)refreshTask=null}
 }
 function accept(k,s,proof=false){if(s.metadata&&(s.metadata.fromCache||s.metadata.hasPendingWrites)){confidence[k]=false;stale=true;emit();return false}
  const d=s.exists()?s.data():null;if(!d&&!k.startsWith('score')){confidence[k]=false;stale=true;emit();return false}
  const rev=d?revision(k,d):[-1];if(highest[k]&&less(rev,highest[k])){confidence[k]=false;stale=true;error='older-revision-rejected';emit();return false}
  if(d)highest[k]=rev;confidence[k]=true;values[k]=d;versions[k]=(versions[k]||0)+1;
  metrics.add(proof?'independentConfirmed':'snapshotConfirmed',k.startsWith('score')?'scores':k);
  if(k==='runtime'||k==='publication')dynamicSources();compose();return true;
 }
 function watch(k,path){paths[k]=path;const gen=epoch,closedMetric=metrics.open(k.startsWith('score')?'scores':k,path);let fingerprint,closed=false;
  const cancel=full.onSnapshot(full.doc(db,path),{includeMetadataChanges:true},s=>{if(closed||gen!==epoch||paths[k]!==path)return;const fp=JSON.stringify(s.exists()?s.data():null);if(!s.metadata.fromCache&&!s.metadata.hasPendingWrites&&fp===fingerprint){confidence[k]=true;metrics.add('metadataNotification',k);compose();return}const accepted=accept(k,s);if(accepted&&!s.metadata.fromCache&&!s.metadata.hasPendingWrites)fingerprint=fp;if(['runtime','publication','round','timer'].every(x=>values[x])&&!lastProof)probe().catch(()=>{});},e=>{if(closed||gen!==epoch||paths[k]!==path)return;stale=true;error=e.code||'source-error';if(e.code==='permission-denied'){if(k==='round'||k.startsWith('score'))retiredScope();else denied()}emit()});return()=>{closed=true;cancel();closedMetric()};
 }
 async function probe(){if(probing||!code)return false;if(!paths.round)return refreshRuntime();const probeToken={};probing=probeToken;const gen=epoch,currentScope=scope,entries=Object.entries(paths),at={...versions};try{
  const all=await Promise.all(entries.map(async([k,p])=>{metrics.add('independentRequested',k.startsWith('score')?'scores':k);try{return await liteSDK.getDoc(liteSDK.doc(lite,p))}catch(e){e.feedKey=k;throw e}}));
  if(gen!==epoch||currentScope!==scope||entries.some(([k,p])=>paths[k]!==p||versions[k]!==at[k])){metrics.add('discardedLateProof','network');if(proofRetries++<1)retryProbe();return false}
  for(let i=0;i<all.length;i++){const [k,p]=entries[i];if(gen!==epoch||currentScope!==scope||paths[k]!==p||!accept(k,all[i],true))return false}if(gen!==epoch||currentScope!==scope)return false;lastProof=now();proofRetries=0;compose();return !stale;
 }catch(e){if(gen!==epoch)return false;if(currentScope!==scope){metrics.add('discardedLateProof','network');retryProbe();return false}stale=true;error=e.code||'network';if(e.code==='permission-denied'){if(e.feedKey==='round'||e.feedKey?.startsWith('score'))retiredScope();else denied()}emit();return false}finally{if(probing===probeToken)probing=null}}
 function stop(){epoch++;off.forEach(f=>f());dynamic.forEach(f=>f());off=[];dynamic=[];clearInterval(timer);clearTimeout(retryProof);retryProof=null;timer=null;values={};paths={};highest={};versions={};confidence={};feed=null;lastProof=0;stale=true;code='';scope='';refreshTask=null;probing=null;proofRetries=0;lastRecovery={scope:'',at:0};emit()}
 function start(next,courts){const clean=mapping(courts).map(c=>c.number);if(next===code&&JSON.stringify(clean)===JSON.stringify(selected))return;stop();selected=clean;code=next;if(!code)return;off=[watch('publication','tournaments/'+code),watch('runtime','tournaments/'+code+'/runtime/current'),watch('timer','tournaments/'+code+'/roundTimer/current')];timer=setInterval(()=>probe(),intervalMs);timer.unref?.()}
 return {start,stop,probe,snapshot,offline(){stale=true;emit()},close:stop};
}
module.exports={createFeed};
