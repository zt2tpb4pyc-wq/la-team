'use strict';
require('./network-guard.cjs');
const {app,BrowserWindow,ipcMain,session,dialog,safeStorage,clipboard,Menu}=require('electron');
const path=require('node:path');
const {createClient}=require('./client.cjs'),{persistenceClass}=require('../desktop-040/vault.cjs'),{createPresentation}=require('./presentation.cjs'),{createFullscreenPolicy,isProjectionURL}=require('../desktop-040/fullscreen-policy.cjs');
const candidate=require('./candidate.json');
app.setName(candidate.name);
app.setPath('userData',path.resolve(process.env.CLUB_TOURNAMENT_DATA||path.join(app.getPath('appData'),require('./config.cjs').mode==='EXISTING_TEST'?'NEXT PADEL Club CONNECT TEST 100':'NEXT PADEL Club CONNECT EMULATOR 100')));
let main,client,view,origin,ready=false,fatal=false,operation=false,quitting=false,closed=false;
const projections=new WeakSet();
function state(s){view?.setRemote({...s,ready})}
function fail(e){if(fatal)return;fatal=true;state({error:'PILOT_INTERNAL_ERROR_RESTART_REQUIRED',mode:'EXISTING_TEST',display:null,stale:true});Promise.resolve(client?.close()).catch(()=>{});console.error('CLUB_VISUAL_FATAL',String(e?.code||'INTERNAL_ERROR').replace(/[^A-Z0-9_/-]/gi,''))}
process.on('uncaughtException',fail);process.on('unhandledRejection',fail);
function openProjection(p){const r=view.issue(p.court,p.mode);if(p.editor!==undefined&&!/^[a-z0-9-]{36}$/.test(p.editor))throw Error('EDITOR_REFUSED');const url=r.url+(p.editor?'&editor='+p.editor:'');const w=new BrowserWindow({width:1280,height:800,title:'NEXT PADEL · Terrain '+p.court,backgroundColor:'#000',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,backgroundThrottling:false}});projections.add(w.webContents);w.loadURL(url);return {ok:true}}
if(!app.requestSingleInstanceLock())app.exit(0);else{
 app.on('second-instance',()=>{main?.show();main?.focus()});
 app.whenReady().then(async()=>{
  Menu.setApplicationMenu(Menu.buildFromTemplate([{label:app.getName(),submenu:[{role:'quit'}]},{role:'editMenu'}]));
  view=createPresentation({directory:path.join(app.getPath('userData'),'presentation'),onChange:s=>{if(main&&!main.isDestroyed())main.webContents.send('club-ui:state',s)}});origin=await view.listen();
  session.defaultSession.webRequest.onBeforeRequest((d,done)=>{let allowed=false;try{allowed=new URL(d.url).origin.replace(/^ws:/,'http:')===origin||d.url==='about:blank'}catch{}done({cancel:!allowed})});
  const permit=createFullscreenPolicy({origin,isProjectionContents:c=>projections.has(c)});
  session.defaultSession.setPermissionRequestHandler((c,p,reply,d)=>reply(permit(c,p,d)));session.defaultSession.setPermissionCheckHandler((c,p,o,d)=>permit(c,p,d,o));
  app.on('web-contents-created',(_,c)=>{c.setWindowOpenHandler(()=>({action:'deny'}));c.on('will-attach-webview',e=>e.preventDefault());c.on('will-navigate',e=>e.preventDefault())});
  ipcMain.handle('club-ui:action',async(e,action,p={})=>{
   if(e.sender!==main?.webContents||e.senderFrame!==e.sender.mainFrame||e.senderFrame.url!==origin+'/')throw Error('IPC_ORIGIN_REFUSED');
   if(typeof action!=='string'||!p||typeof p!=='object'||Array.isArray(p)||JSON.stringify(p).length>65536)throw Error('ACTION_REFUSED');
   if(action==='state'){const s=view.snapshot();return {...s,remote:client&&!fatal?{...client.snapshot(),ready}:s.remote}};
   if(action==='save')return view.save(p.config,p.revision);
   if(action==='appearance')return view.appearance.save(p);
   if(action==='scenario')return view.scene(p.scene);
   if(action==='screen')return view.issue(p.court,p.mode);
   if(action==='openScreen')return openProjection(p);
   if(action==='broadcast')return view.enable(p.enabled);
   if(action==='copyDiagnostic'){const s=view.snapshot(),r=s.remote;clipboard.writeText(JSON.stringify({diagnostic:candidate.name+' '+candidate.version,mode:r.mode,ready:r.ready,identityPresent:r.identityPresent,grantStatus:r.grantStatus,error:r.error,revision:s.revision,metrics:r.metrics},null,2));return {ok:true}};
   if(fatal)throw Error('PILOT_INTERNAL_ERROR_RESTART_REQUIRED');
   if(!ready||!client)throw Error('CLIENT_INITIALIZING');
   if(action==='copyInvite'){clipboard.writeText(client.snapshot().invitation?.url||'');return {ok:true}}
   if(operation)throw Error('OPERATION_PENDING');operation=true;
   try{switch(action){
    case 'identity':await client.identity();break;
    case 'invite':await client.identity();await client.invitation();return {ok:true};
    case 'approve':{const nonce=client.nonce();if(!client.snapshot().invitation?.pending)throw Error('NOT_PENDING');const a=await dialog.showMessageBox(main,{type:'question',title:'Confirmer l’association TEST',message:'Confirmer la demande de votre Organisateur sur ce Mac ?',detail:'Club : '+client.snapshot().club+'. Lecture du seul tournoi sélectionné, quatre terrains maximum, cinq heures. Cette association ne donne aucun droit sportif à ce Mac ni à l’Organisateur.',buttons:['Annuler','Confirmer sur ce Mac'],defaultId:0,cancelId:0,noLink:true});if(a.response!==1)return {ok:false};await client.approve(nonce);break}
    case 'reject':await client.reject();break;
    case 'revoke':await client.revoke();break;
    case 'reconnect':await client.reconnect();break;
    case 'disconnect':await client.disconnect();break;
    default:throw Error('ACTION_REFUSED');
   }return {ok:true};}finally{operation=false}
  });
  main=new BrowserWindow({width:1440,height:960,minWidth:850,minHeight:600,title:candidate.name+' · '+candidate.version,icon:path.join(__dirname,process.platform==='win32'?'../desktop-040/NextPadel.ico':'../desktop-040/NextPadel.icns'),webPreferences:{preload:path.join(__dirname,'../desktop-040/preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});main.on('closed',()=>app.quit());await main.loadURL(origin+'/');
  try{client=createClient({courtNames:()=>view.snapshot().config.courtNames,persistence:persistenceClass(path.join(app.getPath('userData'),'identity'),safeStorage),onChange:state});await client.init();ready=true;state(client.snapshot())}catch(e){state({error:e.code||e.message,mode:'EXISTING_TEST',identityPresent:false});await client?.close().catch(()=>{});client=null}
 });
 app.on('window-all-closed',()=>app.quit());
 app.on('before-quit',e=>{if(closed)return;e.preventDefault();if(quitting)return;quitting=true;Promise.allSettled([Promise.resolve().then(()=>client?.close()),Promise.resolve().then(()=>view?.close())]).finally(()=>{closed=true;app.quit()})});
}
