'use strict';
const Base=require('../desktop-040/model.cjs');
const names=()=>Array.from({length:8},(_,i)=>'Terrain '+(i+1));
function normalize(raw){const {courtNames=names(),...base}=raw||{};if(!Array.isArray(courtNames)||courtNames.length!==8||courtNames.some(n=>typeof n!=='string'||!n.trim()||n.length>60||/[\x00-\x1f\x7f]/.test(n)))throw Error('Huit noms de terrains sont requis (1 à 60 caractères).');return {...Base.normalize(base),courtNames:courtNames.map(n=>n.trim())}}
function mapping(courts){if(!Array.isArray(courts)||courts.length<1||courts.length>4||new Set(courts).size!==courts.length||courts.some(n=>!Number.isInteger(n)||n<1||n>8))throw Error('Choisissez un à quatre terrains distincts parmi huit.');return courts.map((number,i)=>({number,id:'court-'+number,sportRank:i+1}))}
module.exports={...Base,defaults:()=>({...Base.defaults(),courtNames:names()}),normalize,mapping};
