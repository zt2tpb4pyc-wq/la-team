'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const M=require('../physical-model.cjs'),{createPresentation}=require('../presentation.cjs'),{createFeed}=require('../canonical-feed.cjs'),{createMetrics}=require('../metrics.cjs'),{WebSocket}=require('ws');
const selections=[[8],[1,5,8],[2,4,7],[1,2,3,4],[1,3,5,8],[2,4,6,7]];
for(const selected of selections)test('Canonical ranks map to physical '+selected,async()=>{
 const watchers=new Map(),docs=new Map(),snap=d=>({exists:()=>d!=null,data:()=>d,metadata:{}}),full={doc:(_,p)=>p,onSnapshot(p,o,fn){watchers.set(p,fn);return()=>watchers.delete(p)}},liteSDK={doc:(_,p)=>p,getDoc:async p=>snap(docs.get(p))};
 const feed=createFeed({db:{},lite:{},full,liteSDK,metrics:createMetrics()});const send=(p,d)=>{docs.set(p,d);watchers.get(p)?.(snap(d))};
 try{feed.start('ABCD2345',selected);send('tournaments/ABCD2345',{clubId:'club',tournamentId:'game',revision:1,status:'live',endMode:'time',players:Array.from({length:16},(_,i)=>({name:'P'+i})),roundDurationMinutes:1});
 for(let r=1;r<=3;r++){send('tournaments/ABCD2345/runtime/current',{revision:r,roundNumber:r,activeScheduleVersion:r,status:'live'});send('tournaments/ABCD2345/rounds/r'+r,{roundNumber:r,assignmentVersion:r,courts:selected.map((_,i)=>({number:i+1,teamA:[i*4,i*4+1],teamB:[i*4+2,i*4+3]}))});for(let rank=1;rank<=selected.length;rank++)send(`clubs/club/tournaments/game/matches/game_v${r}r${r}c${rank}`,{matchId:`game_v${r}r${r}c${rank}`,roundNumber:r,status:'validated',scoreA:rank+5,scoreB:2,revision:1});send('tournaments/ABCD2345/roundTimer/current',{roundNumber:r,state:'stopped',remainingMs:10000,generation:r});
 assert.deepEqual(feed.snapshot().feed.courts.map(c=>[c.number,c.sportRank,c.score.a]),selected.map((n,i)=>[n,i+1,i+6]));assert.equal(watchers.size,4+selected.length);assert(![...watchers.keys()].some(p=>/c[5-8]$/.test(p)));}
 }finally{feed.close()}
});
test('Eight names/configurations survive restart; deselected live tickets contain no sports',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'physical-courts-'));let v=createPresentation({directory:dir});const sockets=[];
 try{await v.listen();let c=M.defaults();c.selected=[1,3,5,8];c.courtNames=['Central','Panoramique','Terrain Bleu','Quatre','Cinq','Six','Sept','Huit'];c.courts.courts[7].notes='Configuration conservée';v.save(c,0);await v.close();v=createPresentation({directory:dir});const origin=await v.listen();assert.deepEqual(v.snapshot().config,c);assert.throws(()=>v.save({...c,selected:[1,2,3,4,5]},1));
 const remote={grantStatus:'active',expiresAt:Date.now()+60000,enabled:true,courts:c.selected,display:{...M.fixture('overview4').feed,tournamentId:'one',courts:c.selected.map((number,i)=>({number,sportRank:i+1,teamA:['A','B'],teamB:['C','D']}))},confirmedAt:Date.now()};v.setRemote(remote);
 for(const n of [2,4,6,7])assert.throws(()=>v.issue(n,'live'));
 const link=v.issue(8,'live').url;const ws=new WebSocket(origin.replace('http:','ws:')+'/api/stream?'+new URL(link).hash.slice(1),{origin});sockets.push(ws);let packet;await new Promise((resolve,reject)=>{ws.on('message',d=>{packet=JSON.parse(d);resolve()});ws.on('error',reject)});assert.deepEqual(packet.feed.courts.map(x=>x.name),['Central','Terrain Bleu','Cinq','Huit']);assert.equal(packet.courtName,'Huit');
 c={...c,selected:[2,4,6,7]};v.save(c,1);v.setRemote({...remote,courts:c.selected});await new Promise(r=>setTimeout(r,20));assert.equal(packet.authorized,false);assert.equal(packet.feed,null);assert.equal(v.snapshot().config.courts.courts[7].notes,'Configuration conservée');
 }finally{for(const w of sockets)w.terminate();await v.close();fs.rmSync(dir,{recursive:true,force:true})}
});
test('Names and stable identities reject malformed configuration',()=>{const c=M.defaults();assert.equal(c.courts.courts[7].id,'court-8');assert.throws(()=>M.normalize({...c,courtNames:['x']}));assert.throws(()=>M.mapping([1,1]));assert.throws(()=>M.mapping([0]));assert.throws(()=>M.mapping([1,2,3,4,5]));});
test('New tournament may restart at round one; stale rounds of same tournament remain refused',()=>{const V=require('../generated/ui/projection-view.js');const previous={serial:10,feed:{tournamentId:'old',roundNumber:12,assignmentVersion:3}};assert.equal(V.accept(previous,{serial:11,feed:{tournamentId:'new',roundNumber:1,assignmentVersion:1}}),true);assert.equal(V.accept(previous,{serial:11,feed:{tournamentId:'old',roundNumber:1,assignmentVersion:1}}),false)});
test('Old eight-court configuration migrates names in memory without rewriting original',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'physical-legacy-'));const old=require('../../desktop-040/model.cjs').defaults();old.courts.courts[7].notes='Ancienne configuration';const file=path.join(dir,'visual-configuration.json'),bytes=JSON.stringify({schema:1,revision:5,config:old});fs.writeFileSync(file,bytes);const v=createPresentation({directory:dir});try{await v.listen();assert.equal(v.snapshot().readOnly,false);assert.equal(v.snapshot().config.courtNames[7],'Terrain 8');assert.equal(v.snapshot().config.courts.courts[7].notes,'Ancienne configuration');assert.equal(fs.readFileSync(file,'utf8'),bytes)}finally{await v.close();fs.rmSync(dir,{recursive:true,force:true})}});


test('An unconfirmed overview never labels stale teams as current assignments',()=>{
 const V=require('../generated/ui/projection-view.js'),now=Date.now(),packet={serial:1,authorized:true,mode:'live',accessExpiresAt:now+60000,confirmedAt:now,scene:'connected',court:8,profile:{},overviewPageSize:4,anchor:now,feed:{...M.fixture('overview4',now).feed,courts:[8,3,5,1].map((number,i)=>({number,sportRank:i+1,teamA:['A','B'],teamB:['C','D']}))}};
 assert.equal(V.view(packet,{now}).phase,'overview');
 for(const stalePacket of [{...packet,interrupted:true},{...packet,confirmedAt:now-90001}]){const v=V.view(stalePacket,{now});assert.equal(v.phase,'waiting');assert.equal(v.stale,true);assert.deepEqual(v.courts,[])}
 const restored=V.view({...packet,serial:3,confirmedAt:now+1},{now:now+1});assert.equal(restored.phase,'overview');assert.equal(restored.courts.length,4);
});
