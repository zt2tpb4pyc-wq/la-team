'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict');const {createFeed}=require('../canonical-feed.cjs'),{createMetrics}=require('../metrics.cjs');
function harness(){let clock=100000;const watchers=new Map(),docs=new Map(),pending=[];let delayed=false,calls=0;
const snap=d=>({exists:()=>d!==null&&d!==undefined,data:()=>d,metadata:{fromCache:false,hasPendingWrites:false}});
const full={doc:(_,p)=>p,onSnapshot(p,o,fn,error){watchers.set(p,{fn,error});return()=>watchers.delete(p)}};
const liteSDK={doc:(_,p)=>p,getDoc(p){calls++;return delayed?new Promise((resolve,reject)=>pending.push({p,resolve,reject})):Promise.resolve(snap(docs.get(p)))}};
const metrics=createMetrics(),feed=createFeed({db:{},lite:{},metrics,now:()=>clock,full,liteSDK});
const pub={revision:1,clubId:'lab-club-a',tournamentId:'fixture',status:'live',endMode:'time',players:['A','B','C','D'].map(name=>({name})),roundDurationMinutes:1};
const runtime={revision:1,roundNumber:1,activeScheduleVersion:1,status:'live',updatedAt:100000};const round={roundNumber:1,assignmentVersion:1,courts:[{number:1,teamA:[0,1],teamB:[2,3]}]};const timer={roundNumber:1,state:'running',roundStartedAt:100000,remainingMs:60000,durationMinutes:1,generation:1,updatedAt:100000};
function send(p,d,meta){docs.set(p,d);watchers.get(p)?.fn({...snap(d),...(meta?{metadata:meta}:{})})}
function ready(){feed.start('CODETEST',[1]);send('tournaments/CODETEST',pub);send('tournaments/CODETEST/runtime/current',runtime);send('tournaments/CODETEST/rounds/r1',round);send('clubs/lab-club-a/tournaments/fixture/matches/fixture_v1r1c1',null);send('tournaments/CODETEST/roundTimer/current',timer)}
return {feed,ready,send,pub,runtime,round,timer,watchers,metrics,docs,pending,delay(){delayed=true},tick:n=>clock+=n,get calls(){return calls}}}
const settle=()=>new Promise(r=>setTimeout(r,10));
test('Independent freshness, no per-second requests, local countdown and stale after lease',async()=>{const h=harness();try{h.ready();await settle();assert.equal(h.feed.snapshot().stale,false);assert.equal(h.calls,5);h.tick(40000);assert.equal(h.calls,5);h.tick(50001);assert.equal(h.feed.snapshot().stale,true)}finally{h.feed.close()}});
test('Delayed proof from prior round cannot overwrite the latest round',async()=>{const h=harness();try{h.ready();await settle();h.delay();const proof=h.feed.probe();h.send('tournaments/CODETEST/runtime/current',{...h.runtime,revision:2,roundNumber:2,activeScheduleVersion:2});h.send('tournaments/CODETEST/rounds/r2',{...h.round,roundNumber:2,assignmentVersion:2});h.send('clubs/lab-club-a/tournaments/fixture/matches/fixture_v2r2c1',null);h.send('tournaments/CODETEST/roundTimer/current',{...h.timer,roundNumber:2,generation:2});for(const p of h.pending)p.resolve({exists:()=>true,data:()=>h.docs.get(p.p),metadata:{}});await proof;assert.equal(h.feed.snapshot().feed.roundNumber,2);assert(h.metrics.snapshot().totals['discardedLateProof/network']>=1)}finally{h.feed.close()}});
test('Older revision, cached data and revoked access cannot be presented as recent',async()=>{const h=harness();try{h.ready();await settle();const before=h.feed.snapshot().confirmed;h.send('tournaments/CODETEST/runtime/current',{...h.runtime,revision:0});assert.equal(h.feed.snapshot().stale,true);assert.equal(h.feed.snapshot().confirmed,before);h.send('tournaments/CODETEST/roundTimer/current',h.timer,{fromCache:true});assert.equal(h.feed.snapshot().stale,true);h.watchers.get('tournaments/CODETEST/runtime/current').error({code:'permission-denied'});assert.equal(h.feed.snapshot().feed,null);assert.equal(h.watchers.size,0)}finally{h.feed.close()}});
test('Only confirmed official score becomes part of the minimal display contract',async()=>{const h=harness();try{h.ready();await settle();const path='clubs/lab-club-a/tournaments/fixture/matches/fixture_v1r1c1';h.send(path,{matchId:'fixture_v1r1c1',roundNumber:1,courtNumber:1,status:'validated',scoreA:9,scoreB:5,revision:1,validatedByUid:'private-not-for-display'});assert.equal(h.feed.snapshot().feed.courts[0].score.a,9);assert(!JSON.stringify(h.feed.snapshot().feed).includes('private-not-for-display'));h.send(path,{matchId:'fixture_v1r1c1',roundNumber:1,courtNumber:1,status:'validated',scoreA:1,scoreB:0,revision:0});assert.equal(h.feed.snapshot().feed.courts[0].score.a,9)}finally{h.feed.close()}});

test('A repeated older snapshot and an independent older response never renew freshness',async()=>{const h=harness();try{h.ready();await settle();const previous=h.feed.snapshot().confirmed;h.tick(1000);h.send('tournaments/CODETEST/runtime/current',{...h.runtime,revision:0});h.send('tournaments/CODETEST/runtime/current',{...h.runtime,revision:0});assert.equal(h.feed.snapshot().stale,true);assert.equal(await h.feed.probe(),false);assert.equal(h.feed.snapshot().confirmed,previous);assert.equal(h.feed.snapshot().stale,true)}finally{h.feed.close()}});


test('Cloud ordering: old-round permission loss before the runtime notification recovers the new overview',async()=>{
 const h=harness();try{h.ready();await settle();
  h.docs.set('tournaments/CODETEST/runtime/current',{...h.runtime,revision:2,roundNumber:2,activeScheduleVersion:1});
  h.docs.set('tournaments/CODETEST/rounds/v1_r2',{...h.round,roundNumber:2,assignmentVersion:1,courts:[{number:1,teamA:[0,2],teamB:[1,3]}]});
  h.docs.set('tournaments/CODETEST/roundTimer/current',{...h.timer,state:'completed',remainingMs:0});
  h.watchers.get('clubs/lab-club-a/tournaments/fixture/matches/fixture_v1r1c1').error({code:'permission-denied'});
  assert.equal(h.feed.snapshot().feed,null,'Old assignments disappear immediately');
  await settle();await settle();
  assert.equal(h.feed.snapshot().code,'CODETEST');
  assert.equal(h.feed.snapshot().feed?.roundNumber,2);
  assert.equal(h.feed.snapshot().feed.timer.state,'not_started','Previous round Timer is normalized read-only');
  assert.deepEqual(h.feed.snapshot().feed.courts[0].teamA,['A','C']);
  assert.equal(h.feed.snapshot().stale,false);
 }finally{h.feed.close()}
});

test('A rejected proof for the retired round cannot stop subscriptions of the next round',async()=>{
 const h=harness();try{h.ready();await settle();h.delay();const proof=h.feed.probe();
  h.send('tournaments/CODETEST/runtime/current',{...h.runtime,revision:2,roundNumber:2,activeScheduleVersion:1});
  assert.equal(h.feed.snapshot().feed,null,'No round-one assignments under round two');
  h.send('tournaments/CODETEST/rounds/v1_r2',{...h.round,roundNumber:2,assignmentVersion:1});
  h.send('clubs/lab-club-a/tournaments/fixture/matches/fixture_v1r2c1',null);
  for(const p of h.pending){if(p.p.includes('/rounds/'))p.reject({code:'permission-denied'});else p.resolve({exists:()=>!!h.docs.get(p.p),data:()=>h.docs.get(p.p),metadata:{}})}
  await proof;
  assert.equal(h.feed.snapshot().code,'CODETEST');
  assert.equal(h.feed.snapshot().feed?.roundNumber,2);
  assert(h.watchers.has('tournaments/CODETEST/rounds/v1_r2'));
 }finally{h.feed.close()}
});

test('A true revoked association still clears the feed during round-scope recovery',async()=>{
 const h=harness();try{h.ready();await settle();h.delay();
  h.watchers.get('clubs/lab-club-a/tournaments/fixture/matches/fixture_v1r1c1').error({code:'permission-denied'});
  await settle();for(const p of h.pending)p.reject({code:'permission-denied'});await settle();
  assert.equal(h.feed.snapshot().feed,null);assert.equal(h.feed.snapshot().error,'permission-denied');assert.equal(h.watchers.size,0);
 }finally{h.feed.close()}
});


test('Reconnect starts a fresh proof while an old connection proof is still pending',async()=>{
 const h=harness();try{h.ready();await settle();h.delay();const oldProof=h.feed.probe();
  const old=h.pending.splice(0);h.feed.stop();h.ready();await settle();
  assert.equal(h.pending.length,5,'New session verifies immediately, without waiting for the old network request');
  for(const p of old)p.reject({code:'unavailable'});await oldProof;
  const pending=h.pending.splice(0);for(const p of pending)p.resolve({exists:()=>!!h.docs.get(p.p),data:()=>h.docs.get(p.p),metadata:{}});
  await settle();assert.equal(h.feed.snapshot().stale,false);
 }finally{h.feed.close()}
});
