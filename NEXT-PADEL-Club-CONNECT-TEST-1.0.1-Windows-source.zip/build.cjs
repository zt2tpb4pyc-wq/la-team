'use strict';
// No publishing, signing service, Firebase CLI, installation or app launch.
const {execFileSync}=require('node:child_process');
execFileSync(process.execPath,['verify.cjs'],{stdio:'inherit'});
for(const key of ['CSC_LINK','CSC_KEY_PASSWORD','WIN_CSC_LINK','WIN_CSC_KEY_PASSWORD','GH_TOKEN','GITHUB_TOKEN'])delete process.env[key];
process.env.CSC_IDENTITY_AUTO_DISCOVERY='false';
require('electron-builder').build({config:require('./electron-builder.json'),targets:require('electron-builder').Platform.WINDOWS.createTarget('nsis',require('electron-builder').Arch.x64),publish:'never'}).then(paths=>console.log(paths.join('\n'))).catch(e=>{console.error(e.message);process.exitCode=1});
