# NEXT PADEL Club CONNECT TEST 1.0.1 — transfert Windows

## Référence et périmètre

Code validé : **1bf9719ed2d3bfa57019fba9b9a08e274a80f744**.
Branche locale de préparation : `codex/club-windows-transfer`.
Projet autorisé : **la-team-v2-test**. Site Organisateur/Joueurs : **https://nextpadel-connect-test-261019.web.app/**.

Cette archive contient les sources nécessaires au client Electron Windows, ses images, `package.json`, le verrou `package-lock.json`, les contrôles et les instructions. Les dépendances et Electron sont téléchargés par npm depuis leurs sources publiques. Elle ne contient aucun `node_modules`, historique Git, compte, UID utilisateur, jeton, coffre chiffré, sauvegarde Mac, tournoi ni journal utilisateur. La configuration Firebase publique est nécessaire au client ; sa clé API publique ne constitue pas une identité ni un secret administrateur.

Le code métier reste celui de 1bf9719. Seule adaptation native : choisir l'icône `.ico` existante sous Windows. Les trois corrections sont conservées :

- QR Joueurs et mode Manuel/Autopilot : déjà sur le site TEST ; leurs sources sont jointes dans `web-reference/`, uniquement pour traçabilité, sans outil de publication.
- Retour des affectations avant chaque round : `club/existing-organizer/canonical-feed.cjs` et `generated/ui/projection-view.js`, avec les tests de transition/reconnexion d'origine.
- Timer et quatre projections : même serveur local, mêmes règles de lecture, même mode Manuel/Autopilot. Aucune commande sportive nouvelle.

## Récupération

Ne pas cloner le dépôt public historique en supposant qu'il contient cette version : le commit applicatif n'y était pas présent lors de l'audit. Utiliser uniquement l'archive source et son SHA-256 transmis après validation du canal de partage. Le transfert n'est confirmé qu'après téléchargement de cette archive sur le PC et concordance de l'empreinte.

Placer les fichiers dans un **nouveau** dossier, par exemple `Documents\NEXT-PADEL-CONNECT-TEST-101`. Ne pas fusionner avec un projet existant. Dans PowerShell :

```powershell
Get-FileHash .\NEXT-PADEL-Club-CONNECT-TEST-1.0.1-Windows-source.zip -Algorithm SHA256
Expand-Archive .\NEXT-PADEL-Club-CONNECT-TEST-1.0.1-Windows-source.zip -DestinationPath .\NEXT-PADEL-CONNECT-TEST-101
Set-Location .\NEXT-PADEL-CONNECT-TEST-101
```

L'archive place directement `package.json` et ce document à la racine. Ne pas transmettre de fichier provenant de `%APPDATA%` ni du dossier Application Support du Mac.

## Installateur déjà préparé (voie courte)

Un installateur NSIS x64 a été produit localement sur Mac : `NEXT-PADEL-Club-CONNECT-TEST-1.0.1-Windows-x64-Setup.exe`. S'il est fourni via le canal de partage autorisé, comparer son SHA-256 au fichier `SHA256SUMS.txt`, puis passer directement à « Installer et première ouverture ». **Node.js et la compilation ne sont pas nécessaires pour installer ce fichier.** L'exécutable n'a pas encore été lancé sur Windows et n'est pas signé commercialement.

```powershell
Get-FileHash .\NEXT-PADEL-Club-CONNECT-TEST-1.0.1-Windows-x64-Setup.exe -Algorithm SHA256
```

## Construire sur le PC Windows x64 (alternative avec les sources)

Prévoir Windows 10/11 x64, Internet et plusieurs Go disponibles. L'installation/démarrage et le coffre sécurisé doivent être vérifiés sur le PC réel : un binaire produit sur Mac n'est pas une validation native Windows. Vérifier l'architecture ; ne pas lancer ce paquet sur un Windows 32 bits. Installer Node.js 24 LTS depuis **https://nodejs.org/** si absent, avec l'accord du propriétaire. Aucun outil payant, Firebase CLI, compte de facturation, certificat ou service de signature n'est nécessaire.

Dans PowerShell, utiliser `npm.cmd` pour éviter les problèmes de politique d'exécution des scripts PowerShell :

```powershell
node --version
node -p "process.platform + ' ' + process.arch"
npm.cmd ci --no-audit --no-fund
npm.cmd test
npm.cmd run dist:win
Get-FileHash .\dist\NEXT-PADEL-Club-CONNECT-TEST-1.0.1-Windows-x64-Setup.exe -Algorithm SHA256
```

Le compilateur est figé : Electron 44.8.0, electron-builder 26.17.0, Firebase 12.18.0, ws 8.21.3. `npm ci` respecte les empreintes du verrou. `npm test` reste local : flux Firestore simulés, serveur de projection sur 127.0.0.1, aucune identité ni donnée cloud. La compilation cible exclusivement NSIS Windows x64, désactive toute publication et tout lancement automatique. Les outils de compilation peuvent télécharger des dépendances officielles de npm/GitHub, sans écriture Firebase.

En cas d'échec d'intégrité, de téléchargement ou de protection Windows, arrêter et diagnostiquer. Ne pas désactiver SmartScreen/Defender, ne pas modifier de politique d'exécution, ne pas ajouter d'exclusion antivirus. Ce candidat TEST n'a pas de signature commerciale : Windows peut demander une décision explicite au propriétaire. Ne pas acheter de certificat pour cet essai.

## Installer et première ouverture

1. Vérifier qu'aucune application portant déjà exactement le nom **NEXT PADEL Club CONNECT TEST** n'est installée sur ce PC. Si c'est le cas, arrêter avant tout remplacement et proposer une sauvegarde.
2. Lancer l'installateur vérifié, choisir l'installation pour l'utilisateur courant dans un nouveau dossier. Il ne doit demander ni administrateur, ni paiement, ni abonnement.
3. Ouvrir manuellement **NEXT PADEL Club CONNECT TEST**. Le titre mentionne 1.0.1 ; vérifier l'écran Jour/Nuit et les huit terrains configurables.
4. Les données Windows sont propres au PC, dans `%APPDATA%\NEXT PADEL Club CONNECT TEST 100`. Ne jamais y copier l'identité chiffrée du Mac ; le coffre sécurisé utilise le compte Windows.
5. Ne pas créer une invitation QR avant d'être prêt à remplacer volontairement l'association actuelle.

## Association : effet à connaître avant de tester

La version 1.0.1 gère **une association active par compte Organisateur** (`ccGrants/<uid Organisateur>`). Confirmer une nouvelle association Windows avec le même Organisateur remplace les droits de l'ancien Mac et peut couper ses écrans. Ce transfert n'ajoute pas la diffusion simultanée sur deux ordinateurs. Aucun droit n'est cloné ; aucune règle n'est changée.

Pour tester le PC, convenir explicitement avec l'utilisateur du passage Mac → Windows, puis :

1. Dans Chrome, ouvrir le site TEST ci-dessus et se connecter avec le compte Organisateur habituel. Conserver le tournoi TEST récupérable ; ne créer aucun tournoi ni joueur supplémentaire.
2. Dans Club Windows, choisir **Connecter un Organisateur**, puis copier le lien du QR dans Chrome ou scanner le QR depuis une session Organisateur. Les libellés de confirmation disent encore « Mac » dans cette version ; ils désignent l'ordinateur Club qui affiche le QR.
3. Dans NEXT PADEL, utiliser **Connecter un club**, puis confirmer la demande dans Club Windows. Le QR est temporaire ; l'autorisation expire après cinq heures.
4. Reprendre exactement les terrains **8, 3, 5, 1**, dans cet ordre de rang King, avec **Central**, **Panoramique**, **Terrain Bleu**, **Terrain 1**. Configurer leurs noms avant d'activer la diffusion. Une correspondance existante conserve ses noms : ne pas la réécrire pour forcer une divergence.
5. Sélectionner le tournoi TEST existant et autoriser sa diffusion. Ouvrir quatre fenêtres locales, une par terrain. Avant le round, elles doivent toutes montrer les 16 joueurs et les mêmes affectations confirmées.
6. Sur l'iPhone 5G, garder l'inscription actuelle ou scanner le QR Joueurs habituel affiché sur la fiche. Aucun compte/admission technique supplémentaire.
7. L'utilisateur seul lance le round et le Timer. Codex ne déclenche ni round, ni pause, ni STOP, ni score.

Si la session expirée ne retrouve pas son flux, utiliser **Déconnecter temporairement**, puis **Reconnecter** sur le même appareil ; une autorisation expirée nécessite un nouveau QR et sa confirmation. Ne jamais restaurer un jeton ni modifier les règles pour contourner un refus.

## Contrôles et retour arrière

Les sources et assets sont vérifiés par `npm run verify` et `SOURCE-PROVENANCE.json`. Le code du flux, des terrains, du Timer et des protections reste identique au candidat Mac validé, hors choix d'icône. Les tests n'affirment ni une validation native Windows, ni un nouveau contrôle du plan Spark : aucune API de gestion Firebase n'est appelée durant ce transfert. L'application ne modifie pas le plan Firebase. Les quatre fenêtres utilisent le flux local ; le PC associé aura sa propre consommation de client, sans synchronisation Firestore chaque seconde.

En cas de défaut Windows, fermer puis désinstaller seulement **CONNECT TEST** depuis les paramètres Windows. L'installateur conserve les données locales au désinstallateur. Garder le ZIP et le hash pour reproduire le build. Aucun retour arrière de règles, Hosting ou données sportives n'est nécessaire. Si le PC avait remplacé l'association Mac, le retour au Mac se fait par son QR normal et confirmation, avec l'accord de l'utilisateur ; aucune ancienne session ne doit récupérer automatiquement ses droits.

## Message à donner à Codex sur Windows

> Prépare NEXT PADEL Club CONNECT TEST 1.0.1 à partir des fichiers fournis. Si l'installateur .exe est présent, vérifie d'abord son SHA-256 et utilise-le sans recompiler. Sinon, utilise l'archive source. Lis TRANSFERT-WINDOWS.md et SOURCE-PROVENANCE.json. Vérifie l'empreinte reçue, les sources issues de 1bf9719ed2d3bfa57019fba9b9a08e274a80f744 et Windows x64. Utilise un nouveau dossier, Node 24, npm.cmd ci, npm.cmd test et npm.cmd run dist:win. N'écrase aucune application existante. Vérifie l'installateur et aide-moi à installer uniquement cette application TEST indépendante. Ne modifie aucun projet Firebase, règle, Hosting, tournoi ou inscription. Ne copie aucune identité du Mac. Avant l'association QR, explique que le même Organisateur ne peut avoir qu'un ordinateur Club actif et attends mon choix de basculer du Mac vers Windows. Ne lance aucun round ni Timer. Vérifie le démarrage natif et quatre projections avec moi. Signale toute erreur sans contourner les protections Windows et sans service payant.

Références techniques : https://www.electron.build/v26/docs/nsis/ ; https://www.electron.build/v26/docs/features/multi-platform-build/ ; https://www.electronjs.org/docs/latest/api/safe-storage .
